#include <iostream>
#include <memory>
#include <vector>
#include <algorithm>
#include <chrono>
#include <thread>
#include <iomanip>
#include <sstream>
#include <ctime>

// Prototype
class Shape {
public:
    virtual std::unique_ptr<Shape> clone() const = 0;
    virtual void draw() const = 0;
    virtual ~Shape() = default;
};

class Circle : public Shape {
    int radius;
public:
    Circle(int r) : radius(r) {}

    std::unique_ptr<Shape> clone() const override {
        return std::make_unique<Circle>(*this);
    }

    void draw() const override {
        std::cout << "Circle with radius " << radius << std::endl;
    }
};

void prototype_demo() {
    std::unique_ptr<Shape> original = std::make_unique<Circle>(10);
    std::unique_ptr<Shape> clone = original->clone();

    original->draw();  // Output: Circle with radius 10
    clone->draw();     // Output: Circle with radius 10
}

// Composite
class Graphic {
public:
    virtual void draw() const = 0;
    virtual ~Graphic() = default;
};

class Line : public Graphic {
public:
    void draw() const override {
        std::cout << "Drawing a line" << std::endl;
    }
};

class CompositeGraphic : public Graphic {
    std::vector<std::shared_ptr<Graphic>> graphics;
public:
    void add(std::shared_ptr<Graphic> graphic) {
        graphics.push_back(graphic);
    }

    void remove(std::shared_ptr<Graphic> graphic) {
        graphics.erase(std::remove(graphics.begin(), graphics.end(), graphic), graphics.end());
    }

    void draw() const override {
        for (const auto& graphic : graphics) {
            graphic->draw();
        }
    }
};

void composite_demo() {
    auto line1 = std::make_shared<Line>();
    auto line2 = std::make_shared<Line>();

    CompositeGraphic graphic;
    graphic.add(line1);
    graphic.add(line2);
    graphic.draw();  // Output: Drawing a line
    //         Drawing a line
}

// Scheduled Task
void task() {
    auto now = std::chrono::system_clock::now();
    std::time_t now_c = std::chrono::system_clock::to_time_t(now);
    std::tm now_tm;
    localtime_s(&now_tm, &now_c);
    std::ostringstream oss;
    oss << std::put_time(&now_tm, "%Y-%m-%d %H:%M:%S");
    std::cout << "Task executed at " << oss.str() << std::endl;
}

void scheduled_task_demo() {
    using namespace std::chrono_literals;
    while (true) {
        std::this_thread::sleep_for(5s);
        task();
    }
}

// Balking
class Balking {
    bool is_ready;
public:
    Balking() : is_ready(false) {}

    void prepare() {
        is_ready = true;
        std::cout << "Object is ready" << std::endl;
    }

    void execute() {
        if (!is_ready) {
            std::cout << "Balking: Object is not ready" << std::endl;
            return;
        }
        std::cout << "Executing task" << std::endl;
        is_ready = false;  // Reset state after execution
    }
};

void balking_demo() {
    Balking balking;
    balking.execute();  // Output: Balking: Object is not ready
    balking.prepare();
    balking.execute();  // Output: Object is ready
    //         Executing task
}

int main() {
    std::cout << "Prototype Demo:" << std::endl;
    prototype_demo();

    std::cout << "\nComposite Demo:" << std::endl;
    composite_demo();

    std::cout << "\nScheduled Task Demo:" << std::endl;
    std::thread t(scheduled_task_demo);
    std::this_thread::sleep_for(std::chrono::seconds(10));  // Run the scheduled task demo for 10 seconds
    t.detach();

    std::cout << "\nBalking Demo:" << std::endl;
    balking_demo();

    return 0;
}